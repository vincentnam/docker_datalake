import * as minio from "minio";
const mc = new minio.Client(
    {
            endPoint: "localhost",
            useSSL: false,
            port: 9000,
            accessKey: "admin",
            secretKey: "adminadmin",
            signatureVersion: "v4",
    },


);
export default mc